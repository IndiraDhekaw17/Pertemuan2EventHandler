package com.chirikualii.materiapi.data.model

data class Movie (
    val title:String,
    val genre:String,
    val imagePoster:String)