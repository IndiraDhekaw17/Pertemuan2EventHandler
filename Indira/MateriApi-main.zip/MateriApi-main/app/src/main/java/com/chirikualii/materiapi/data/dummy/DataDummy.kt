package com.chirikualii.materiapi.data.dummy

import com.chirikualii.materiapi.data.model.Movie

object DataDummy {
    val listMovie = listOf(
        Movie(
            "Avengers: Endgame",
            "Action, Adventure, Drama",
            "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg"
        ),
        Movie(
            "Alita: Battle Angel",
            "Action, Adventure, Science Fiction",
            "https://image.tmdb.org/t/p/w500/xRWht48C2V8XNfzvPehyClOvDni.jpg"
        ),
        Movie(
            "Captain Marvel",
            "Action, Adventure, Science Fiction",
            "https://image.tmdb.org/t/p/w500/AtsgWhDnHTq68L0lLsUrCnM7TjG.jpg"
        ),
        Movie(
            "Aquaman",
            "Action, Adventure, Fantasy",
            "https://image.tmdb.org/t/p/w500/5Kg76ldv7VxeX9YlcQXiowHgdX6.jpg"
        ),
        Movie(
            "Bohemian Rhapsody",
            "Drama, Music",
            "https://image.tmdb.org/t/p/w500/lHu1wtNaczFPGFDTrjCSzeLPTKN.jpg"
        ),
        Movie( "Cold Pursuit",
            "Action, Crime, Thriller",
            "https://image.tmdb.org/t/p/w500/hXgmWPd1SuujRZ4QnKLzrj79PAw.jpg"
        ),
        Movie(
            "Creed II",
            "Drama",
            "https://image.tmdb.org/t/p/w500/v3QyboWRoA4O9RbcsqH8tJMe8EB.jpg"
        ),

        Movie(
            "Fantastic Beasts: The Crimes of Grindelwald",
            "Adventure, Fantasy, Drama",
            "https://image.tmdb.org/t/p/w500/fMMrl8fD9gRCFJvsx0SuFwkEOop.jpg"
        ),

        Movie(
            "Glass",
            "Thriller, Drama, Science Fiction",
            "https://image.tmdb.org/t/p/w500/svIDTNUoajS8dLEo7EosxvyAsgJ.jpg"
        ),

        Movie(
            "How to Train Your Dragon: The Hidden World",
            "Animation, Family, Adventure",
            "https://image.tmdb.org/t/p/w500/xvx4Yhf0DVH8G4LzNISpMfFBDy2.jpg"
        ),
        Movie(
            "Mary Poppins Returns",
            "Family, Comedy, Fantasy",
            "https://image.tmdb.org/t/p/w500/uTVGku4LibMGyKgQvjBtv3OYfAX.jpg"
        ),

        Movie(
            "Aquaman",
            "Action, Adventure, Fantasy",
            "https://image.tmdb.org/t/p/w500/5Kg76ldv7VxeX9YlcQXiowHgdX6.jpg"
        ),

        Movie(
            "How to Train Your Dragon: The Hidden World",
            "Animation, Family, Adventure",
            "https://image.tmdb.org/t/p/w500/xvx4Yhf0DVH8G4LzNISpMfFBDy2.jpg"
        ),

        Movie(
            "Bohemian Rhapsody",
            "Drama, Music",
            "https://image.tmdb.org/t/p/w500/lHu1wtNaczFPGFDTrjCSzeLPTKN.jpg"
        ),
        Movie( "Cold Pursuit",
            "Action, Crime, Thriller",
            "https://image.tmdb.org/t/p/w500/hXgmWPd1SuujRZ4QnKLzrj79PAw.jpg"
        ),
        Movie(
            "Creed II",
            "Drama",
            "https://image.tmdb.org/t/p/w500/v3QyboWRoA4O9RbcsqH8tJMe8EB.jpg"
        ),

        Movie(
            "Fantastic Beasts: The Crimes of Grindelwald",
            "Adventure, Fantasy, Drama",
            "https://image.tmdb.org/t/p/w500/fMMrl8fD9gRCFJvsx0SuFwkEOop.jpg"
        ),

        Movie(
            "Glass",
            "Thriller, Drama, Science Fiction",
            "https://image.tmdb.org/t/p/w500/svIDTNUoajS8dLEo7EosxvyAsgJ.jpg"
        ),

        Movie(
            "How to Train Your Dragon: The Hidden World",
            "Animation, Family, Adventure",
            "https://image.tmdb.org/t/p/w500/xvx4Yhf0DVH8G4LzNISpMfFBDy2.jpg"
        ),
        Movie(
            "Mary Poppins Returns",
            "Family, Comedy, Fantasy",
            "https://image.tmdb.org/t/p/w500/uTVGku4LibMGyKgQvjBtv3OYfAX.jpg"
        ),

        Movie(
            "Aquaman",
            "Action, Adventure, Fantasy",
            "https://image.tmdb.org/t/p/w500/5Kg76ldv7VxeX9YlcQXiowHgdX6.jpg"
        ),

        Movie(
            "How to Train Your Dragon: The Hidden World",
            "Animation, Family, Adventure",
            "https://image.tmdb.org/t/p/w500/xvx4Yhf0DVH8G4LzNISpMfFBDy2.jpg"
        ),

        Movie(
            "Bohemian Rhapsody",
            "Drama, Music",
            "https://image.tmdb.org/t/p/w500/lHu1wtNaczFPGFDTrjCSzeLPTKN.jpg"
        ),
        Movie( "Cold Pursuit",
            "Action, Crime, Thriller",
            "https://image.tmdb.org/t/p/w500/hXgmWPd1SuujRZ4QnKLzrj79PAw.jpg"
        ),
        Movie(
            "Creed II",
            "Drama",
            "https://image.tmdb.org/t/p/w500/v3QyboWRoA4O9RbcsqH8tJMe8EB.jpg"
        ),

        Movie(
            "Fantastic Beasts: The Crimes of Grindelwald",
            "Adventure, Fantasy, Drama",
            "https://image.tmdb.org/t/p/w500/fMMrl8fD9gRCFJvsx0SuFwkEOop.jpg"
        ),

        Movie(
            "Glass",
            "Thriller, Drama, Science Fiction",
            "https://image.tmdb.org/t/p/w500/svIDTNUoajS8dLEo7EosxvyAsgJ.jpg"
        ),

        Movie(
            "How to Train Your Dragon: The Hidden World",
            "Animation, Family, Adventure",
            "https://image.tmdb.org/t/p/w500/xvx4Yhf0DVH8G4LzNISpMfFBDy2.jpg"
        ),
        Movie(
            "Mary Poppins Returns",
            "Family, Comedy, Fantasy",
            "https://image.tmdb.org/t/p/w500/uTVGku4LibMGyKgQvjBtv3OYfAX.jpg"
        ),

        Movie(
            "Aquaman",
            "Action, Adventure, Fantasy",
            "https://image.tmdb.org/t/p/w500/5Kg76ldv7VxeX9YlcQXiowHgdX6.jpg"
        ),

        Movie(
            "How to Train Your Dragon: The Hidden World",
            "Animation, Family, Adventure",
            "https://image.tmdb.org/t/p/w500/xvx4Yhf0DVH8G4LzNISpMfFBDy2.jpg"
        ),
    )
}